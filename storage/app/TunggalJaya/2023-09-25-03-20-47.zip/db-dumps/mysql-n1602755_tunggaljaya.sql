
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `barangs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barangs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `jenis` varchar(255) DEFAULT NULL,
  `ukuran` varchar(255) DEFAULT NULL,
  `koneksi` varchar(255) DEFAULT NULL,
  `material` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `jumlah` int(11) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `barangs` WRITE;
/*!40000 ALTER TABLE `barangs` DISABLE KEYS */;
INSERT INTO `barangs` VALUES (1,'Swing check','2 inch','10k','Cast iron','Kitz',3,'di rak','2022-10-01 01:14:01','2022-10-01 01:16:34'),(3,'Gate','2 inch','10k','Cast iron','Kitz',3,'di rak','2022-10-01 01:15:17','2022-10-01 01:15:17');
/*!40000 ALTER TABLE `barangs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image_category` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Valve','img/gate-valve.jpg','2022-09-21 22:29:45','2022-09-22 07:51:27'),(2,'Fitting','img/globe-valve.jpg','2022-09-21 22:29:45','2022-09-22 07:51:40'),(3,'Instrument','img/ball-valve.webp','2022-09-21 22:29:45','2022-09-22 07:51:54');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `about` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `telp` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image_company` varchar(255) NOT NULL,
  `lat` double DEFAULT 0,
  `lng` double DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `saldo` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'CV Tunggal Jaya','Kami adalah perusahaan yang bergerak di bidang valve, fitting. Melayani pemesanan valve dan jasa service / reparasi, pemasangan, instalasi pipa hydrant.','Jl. Margodadi 2-89, Kota Surabaya, Jawa Timur','+628125982217','tunggaljaya5902@gmail.com','img/imagecompany.jpg',-7.2492319,112.7247022,'2022-09-21 22:29:45','2022-10-01 00:33:01',30000);
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deleted_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deleted_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_inv` int(11) DEFAULT NULL,
  `no_invoice` varchar(255) NOT NULL,
  `duedate` date DEFAULT NULL,
  `id_customer` varchar(255) DEFAULT NULL,
  `name_customer` varchar(255) DEFAULT NULL,
  `address_customer` varchar(255) DEFAULT NULL,
  `phone_customer` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `diskon_rate` int(11) NOT NULL DEFAULT 0,
  `tax_rate` int(11) NOT NULL DEFAULT 0,
  `profit` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deleted_invoices` WRITE;
/*!40000 ALTER TABLE `deleted_invoices` DISABLE KEYS */;
INSERT INTO `deleted_invoices` VALUES (1,1,'2022/INV/09/0001','2022-09-26',NULL,'Rr','Ff','Gg',NULL,5,0,500000,'2022-09-27 15:52:14','2022-09-27 15:52:14'),(2,1,'2023/INV/04/0001','2023-04-18',NULL,'Test','Hshshs','shshsh',NULL,0,0,0,'2023-04-18 06:13:16','2023-04-18 06:13:16');
/*!40000 ALTER TABLE `deleted_invoices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deleted_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deleted_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_of` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `item_price` int(11) NOT NULL,
  `duedate` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deleted_items` WRITE;
/*!40000 ALTER TABLE `deleted_items` DISABLE KEYS */;
INSERT INTO `deleted_items` VALUES (1,1,'pcs','Ate',1,1000000,'2022-09-26','2022-09-27 15:52:14','2022-09-27 15:52:14'),(2,2,'pcs','hshshs',1,5656565,'2023-04-18','2023-04-18 06:13:16','2023-04-18 06:13:16');
/*!40000 ALTER TABLE `deleted_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image_product` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images_products` WRITE;
/*!40000 ALTER TABLE `images_products` DISABLE KEYS */;
INSERT INTO `images_products` VALUES (1,1,'img/product/gate-valve.jpg','2022-09-21 22:29:45','2022-09-21 22:29:45'),(3,3,'img/product/ball-valve.webp','2022-09-21 22:29:45','2022-09-21 22:29:45'),(5,4,'img/product/1664201126-images (92).jpeg','2022-09-26 07:05:26','2022-09-26 07:05:26'),(6,2,'img/product/1664208951-globe-valve (1).jpg','2022-09-26 09:15:51','2022-09-26 09:15:51'),(7,5,'img/product/1664209281-butterfly valve.jpg','2022-09-26 09:21:21','2022-09-26 09:21:21'),(8,6,'img/product/1664209353-plug valve.jpg','2022-09-26 09:22:33','2022-09-26 09:22:33'),(9,7,'img/product/1664209528-safety valve.jpg','2022-09-26 09:25:28','2022-09-26 09:25:28'),(10,8,'img/product/1664209619-lift-check.jpg','2022-09-26 09:26:59','2022-09-26 09:26:59'),(11,8,'img/product/1664209619-lift-type-check-valve-500x500.jpg','2022-09-26 09:26:59','2022-09-26 09:26:59'),(12,9,'img/product/1664210516-steamtrap.jpg','2022-09-26 09:41:56','2022-09-26 09:41:56'),(13,9,'img/product/1664210516-steamtrap 1.jpg','2022-09-26 09:41:56','2022-09-26 09:41:56');
/*!40000 ALTER TABLE `images_products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images_sliders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images_sliders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image_slider` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images_sliders` WRITE;
/*!40000 ALTER TABLE `images_sliders` DISABLE KEYS */;
INSERT INTO `images_sliders` VALUES (1,'img/valve-cover-1.jpg','2022-09-21 22:29:45','2022-09-21 22:29:45'),(2,'img/valve-cover-2.jpg','2022-09-21 22:29:45','2022-09-21 22:29:45'),(3,'img/valve-cover-3.png','2022-09-21 22:29:45','2022-09-21 22:29:45');
/*!40000 ALTER TABLE `images_sliders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_inv` int(11) DEFAULT NULL,
  `no_invoice` varchar(255) NOT NULL,
  `duedate` date DEFAULT NULL,
  `id_customer` varchar(255) DEFAULT NULL,
  `name_customer` varchar(255) DEFAULT NULL,
  `address_customer` varchar(255) DEFAULT NULL,
  `phone_customer` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `diskon_rate` int(11) NOT NULL DEFAULT 0,
  `tax_rate` int(11) NOT NULL DEFAULT 0,
  `profit` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tanggal_pengiriman` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (2,1,'2022/INV/09/0001','2022-09-27',NULL,'Bpk amir','PT CDN','+62 813-5784-0907','Riper butterflay',0,0,0,'2022-09-27 15:54:29','2022-09-30 08:19:18','2022-09-30'),(3,2,'2022/INV/09/0002','2022-09-30',NULL,'test','suraba','-',NULL,0,0,0,'2022-09-27 17:20:11','2022-09-30 08:18:16','2022-09-30'),(4,3,'2022/INV/09/0003','2022-09-29',NULL,'PT SMSE','Kupang','-','kbhbkhb\r\nhbhbkh',0,0,0,'2022-09-27 18:38:35','2023-06-01 14:58:29','2022-09-30'),(5,1,'2022/INV/12/0001','2022-12-30',NULL,'PT GONDOWANGI TRADISIONAL KOSMETIKA','Kawasan Jababeka I, JL. Jababeka XVII D, Blok U No. 29C Cikarang, Bekasi 17530','-',NULL,0,11,0,'2022-12-30 02:05:57','2023-06-05 21:19:19','2023-06-06'),(7,1,'2023/INV/04/0001','2023-04-11',NULL,'Bpk Irfan','Surabaya','+62 812-3592-8729','Pembelian',0,0,0,'2023-04-18 06:18:22','2023-04-18 06:18:39','2023-04-18'),(9,1,'2023/INV/05/0001','2023-05-26',NULL,'PT SMSE','Kupang','+62 857-2964-6447','- Garansi 6 bulan setelah barang diterima *(Garansi berupa servis di workshop kami)',0,0,0,'2023-05-25 18:14:37','2023-05-29 22:31:32','2023-05-26'),(10,2,'2023/INV/05/0002','2023-05-26',NULL,'Pt smse','Kupang','+62 857-2964-6447','Garansi 6bulan setelah barang diterima ( garansi berupa sarvice di workshop kami)\r\ndkjsbkjdsb\r\ndkshbksb',0,0,0,'2023-05-25 20:12:05','2023-06-01 19:56:14','2023-05-31'),(11,1,'2023/INV/06/0001','2023-06-05',NULL,'Bpk amir','Sidoarjo / tuban','+62 813-5784-0907','Tukar tambah striner KRI',0,0,0,'2023-06-05 05:13:54','2023-06-05 05:13:54','2023-06-05'),(12,2,'2023/INV/06/0002','2023-06-13',NULL,'Bpk samsul','Gersik','+62 812-3555-9990','Jasa pemuatan baut dengan bahan as besi SCM',0,0,0,'2023-06-12 22:10:59','2023-06-12 22:10:59','2023-06-13'),(13,3,'2023/INV/06/0003','2023-06-18',NULL,'Bpk samsul','Gersik','+62 812-3555-9990','Jasa pembuatan baut besi scm non mur',0,0,0,'2023-06-18 14:25:44','2023-06-18 14:25:44','2023-06-18'),(15,4,'2023/INV/06/0004','2023-06-25',NULL,'Bpk samsul','Gersik','+62 812-3555-9990','Jasa fabrikasi baut & bor mur',0,0,0,'2023-06-25 05:33:41','2023-06-25 05:33:41','2023-06-25'),(16,5,'2023/INV/06/0005','2023-06-28',NULL,'Bpk samsul','Gersik','+62 812-3555-9990','Pembuatan baut kunci 24 M16x2 + mur',0,0,0,'2023-06-27 17:15:23','2023-06-27 17:15:23','2023-06-28'),(17,1,'2023/INV/07/0001','2023-07-01',NULL,'Pt smse','Kupang','+62 857-2964-6447',NULL,0,0,0,'2023-07-01 00:54:14','2023-07-01 00:54:14','2023-07-01'),(18,2,'2023/INV/07/0002','2023-07-04',NULL,'Bpk samsul','Gersik','+62 812-3555-9990','Pembuatan baut bahan scm + mur',0,0,0,'2023-07-03 23:07:14','2023-07-03 23:07:14','2023-07-04'),(19,3,'2023/INV/07/0003','2023-07-05',NULL,'Cv fillan berkah qila','Surabaya','+62 813-5876-3346',NULL,0,0,0,'2023-07-04 21:13:20','2023-07-04 21:13:20','2023-07-05'),(20,4,'2023/INV/07/0004','2023-07-10',NULL,'Bpk samsul','Gersik','+62 812-3555-9990','Jasa',0,0,0,'2023-07-10 14:20:33','2023-07-10 14:20:33','2023-07-10'),(21,5,'2023/INV/07/0005','2023-07-11',NULL,'Obex','Waru','+62 823-3135-9894','Jasa tekuk plat almunium',0,0,0,'2023-07-11 02:25:13','2023-07-11 02:25:13','2023-07-11'),(22,6,'2023/INV/07/0006','2023-07-14',NULL,'Pt bricon','Surabaya','+62 822-3392-2206','No rek bca 6710085453\r\nCHUSNUL IMRON\r\nBank Mandiri\r\n1410018628487',0,0,0,'2023-07-13 19:03:16','2023-07-13 19:03:16','2023-07-14'),(23,7,'2023/INV/07/0007','2023-07-14',NULL,'Cv fillan berkah qila','Surabaya','+62 813-5876-3346','Fabrikasi angle & globe nakajima kaki3',0,0,0,'2023-07-14 02:31:10','2023-07-14 02:31:10','2023-07-14'),(24,8,'2023/INV/07/0008','2023-07-20',NULL,'Pak amir','Sidoarjo / tuban','+62 813-5784-0907','Tukar tambah  strainer ss',0,0,0,'2023-07-19 18:39:34','2023-07-19 18:39:34','2023-07-20'),(25,1,'2023/INV/08/0001','2023-08-05',NULL,'Cv villan berkah qila','Surabaya','+62 813-5876-3346','Dp 5jt',0,0,0,'2023-08-05 02:49:15','2023-08-05 02:49:15','2023-08-05'),(26,2,'2023/INV/08/0002','2023-08-08',NULL,'Obex','Surabaya','+62 823-3135-9894','Jasa join.\r\nNo rek an chusnul imron \r\nBca 6710085453\r\nCHUSNUL IMRON\r\nBank Mandiri\r\n1410018628487',0,0,0,'2023-08-08 14:59:41','2023-08-08 15:04:57','2023-08-08'),(27,3,'2023/INV/08/0003','2023-08-22',NULL,'Obex','Surabaya','+62 823-3135-9894','Jasa fabrikasi pembuatan siku dari bahan plat aluminium 5mm',0,0,0,'2023-08-21 22:39:57','2023-08-21 22:39:57','2023-08-22');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_of` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `item_price` int(11) NOT NULL,
  `duedate` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (19,3,'pcs','test',2,500000,'2022-09-30','2022-09-30 08:18:16','2022-09-30 08:18:16'),(21,2,'pcs','Riper butterflay',2,2300000,'2022-09-27','2022-09-30 08:19:18','2022-09-30 08:19:18'),(22,2,'pcs','Join + handle',2,700000,'2022-09-27','2022-09-30 08:19:19','2022-09-30 08:19:19'),(26,7,'pcs','Safety valve spirax sarco pn16/25 80x125  flangs',1,21000000,'2023-04-11','2023-04-18 06:18:39','2023-04-18 06:18:39'),(31,9,'pcs','Globe Valve DN20 PN320/32Mpa',4,6000000,'2023-05-26','2023-05-29 22:31:32','2023-05-29 22:31:32'),(45,4,'pcs','Butterfly Valve DN400 disc stem stainless steel',1,9500000,'2022-09-29','2023-06-01 14:58:29','2023-06-01 14:58:29'),(50,10,'pcs','Globe valve dn10 pn32mpa',1,3900000,'2023-05-26','2023-06-01 19:56:14','2023-06-01 19:56:14'),(57,11,'pcs','Strainer flangs 570x20 + baut',2,1700000,'2023-06-05','2023-06-05 06:12:33','2023-06-05 06:12:33'),(58,11,'pcs','Strainer flangs 390x250+ baut',2,1500000,'2023-06-05','2023-06-05 06:12:33','2023-06-05 06:12:33'),(59,11,'pcs','Strainer flangs 166x200 + baut',2,900000,'2023-06-05','2023-06-05 06:12:33','2023-06-05 06:12:33'),(60,5,'pcs','valve',1,20000,'2022-12-30','2023-06-05 21:19:19','2023-06-05 21:19:19'),(69,12,'pcs','Baut L M44 + mur',2,400000,'2023-06-13','2023-06-12 22:12:36','2023-06-12 22:12:36'),(70,12,'pcs','Baut kunci 24 M16 40mm + mur',50,65000,'2023-06-13','2023-06-12 22:12:36','2023-06-12 22:12:36'),(71,12,'pcs','Baut kunci 24 m16 30mm + mur',50,65000,'2023-06-13','2023-06-12 22:12:36','2023-06-12 22:12:36'),(72,12,'pcs','Baut L m34 + mur',2,250000,'2023-06-13','2023-06-12 22:12:36','2023-06-12 22:12:36'),(101,13,'pcs','Baut L M16x110 drat 40',5,90000,'2023-06-18','2023-06-19 13:25:33','2023-06-19 13:25:33'),(102,13,'pcs','Baut L M16x110 drat 25',5,90000,'2023-06-18','2023-06-19 13:25:33','2023-06-19 13:25:33'),(103,13,'pcs','Baut L M16x30 drat full',20,65000,'2023-06-18','2023-06-19 13:25:33','2023-06-19 13:25:33'),(104,13,'pcs','Baut L M16x55 drat 30',20,65000,'2023-06-18','2023-06-19 13:25:33','2023-06-19 13:25:33'),(105,13,'pcs','Baut L M12x30 drat full',40,50000,'2023-06-18','2023-06-19 13:25:33','2023-06-19 13:25:33'),(106,13,'pcs','Baut pin',4,75000,'2023-06-18','2023-06-19 13:25:33','2023-06-19 13:25:33'),(107,13,'pcs','Baut kunci 25 M16x110 drat 40',5,135000,'2023-06-18','2023-06-19 13:25:33','2023-06-19 13:25:33'),(108,13,'pcs','Baut kunci 24 M16x40',15,65000,'2023-06-18','2023-06-19 13:25:33','2023-06-19 13:25:33'),(109,13,'pcs','Bor mur  lubang 3mm',28,10000,'2023-06-18','2023-06-19 13:25:33','2023-06-19 13:25:33'),(110,13,'pcs','Baut L ½inc x 60',8,90000,'2023-06-18','2023-06-19 13:25:33','2023-06-19 13:25:33'),(132,15,'pcs','Baut L ⅜inc x114',8,90000,'2023-06-25','2023-06-25 05:33:41','2023-06-25 05:33:41'),(133,15,'pcs','Baut L m12x30',10,50000,'2023-06-25','2023-06-25 05:33:41','2023-06-25 05:33:41'),(134,15,'pcs','Bor mur m16 3mm',250,10000,'2023-06-25','2023-06-25 05:33:41','2023-06-25 05:33:41'),(142,17,'pcs','Globe v pn32Mpa dn20 CS BW',1,6000000,'2023-07-01','2023-07-01 17:44:54','2023-07-01 17:44:54'),(150,19,'pcs','Waterflay ci pn16  6\"',2,2350000,'2023-07-05','2023-07-04 21:13:20','2023-07-04 21:13:20'),(151,19,'pcs','Lift check valve pn16 2\"',1,2550000,'2023-07-05','2023-07-04 21:13:20','2023-07-04 21:13:20'),(152,18,'pcs','Baut L m10x 45 + mur',20,90000,'2023-07-04','2023-07-08 16:53:17','2023-07-08 16:53:17'),(153,18,'pcs','Baut l m24x 115  + mur',6,250000,'2023-07-04','2023-07-08 16:53:17','2023-07-08 16:53:17'),(154,18,'pcs','Baut L m24x 50 full',5,110000,'2023-07-04','2023-07-08 16:53:17','2023-07-08 16:53:17'),(155,18,'pcs','Baut m16x40 kunci 24',70,65000,'2023-07-04','2023-07-08 16:53:17','2023-07-08 16:53:17'),(156,18,'pcs','Baut L 38x270',3,400000,'2023-07-04','2023-07-08 16:53:17','2023-07-08 16:53:17'),(157,18,'pcs','Baut L 44x280',3,600000,'2023-07-04','2023-07-08 16:53:17','2023-07-08 16:53:17'),(158,18,'pcs','Baut L 52 x 280',2,1300000,'2023-07-04','2023-07-08 16:53:17','2023-07-08 16:53:17'),(159,18,'pcs','Bolt m18',6,160000,'2023-07-04','2023-07-08 16:53:17','2023-07-08 16:53:17'),(163,21,'pcs','30x30x2000',2,200000,'2023-07-11','2023-07-11 02:25:13','2023-07-11 02:25:13'),(164,22,'pcs','Motorize aqtuator unid 220',1,2250000,'2023-07-14','2023-07-13 19:03:16','2023-07-13 19:03:16'),(167,23,'pcs','Angle valve nakajima kaki3 2½\" bronze pn16',1,7350000,'2023-07-14','2023-07-14 22:50:26','2023-07-14 22:50:26'),(168,23,'pcs','Glibe valve nakajima kaki3 2½\" bronze pn16',1,6250000,'2023-07-14','2023-07-14 22:50:26','2023-07-14 22:50:26'),(169,23,'pcs','Sarfice pembuatan as dan lipping disc seat + handwel',1,1500000,'2023-07-14','2023-07-14 22:50:26','2023-07-14 22:50:26'),(170,24,'pcs','Strainer 90x195x200',2,1000000,'2023-07-20','2023-07-19 18:39:34','2023-07-19 18:39:34'),(171,24,'pcs','Strainer 120x295x405',2,1500000,'2023-07-20','2023-07-19 18:39:34','2023-07-19 18:39:34'),(172,24,'pcs','Straner 100x580x240',1,1300000,'2023-07-20','2023-07-19 18:39:34','2023-07-19 18:39:34'),(173,20,'pcs','Bikin ring ss',10,80000,'2023-07-10','2023-07-28 19:06:19','2023-07-28 19:06:19'),(174,20,'pcs','Bikin ring besi',10,50000,'2023-07-10','2023-07-28 19:06:19','2023-07-28 19:06:19'),(175,20,'pcs','Bor mur m10 ss',50,15000,'2023-07-10','2023-07-28 19:06:19','2023-07-28 19:06:19'),(176,20,'pcs','Spring',1,250000,'2023-07-10','2023-07-28 19:06:19','2023-07-28 19:06:19'),(177,20,'pcs','Jasa spring',1,100000,'2023-07-10','2023-07-28 19:06:19','2023-07-28 19:06:19'),(178,25,'pcs','Ball valve dn50 pn40 fabrikasi',5,3000000,'2023-08-05','2023-08-05 02:49:15','2023-08-05 02:49:15'),(179,25,'pcs','Globe valve hidran kaki3',2,6600000,'2023-08-05','2023-08-05 02:49:15','2023-08-05 02:49:15'),(180,16,'pcs','Baut M16x75×40',200,70000,'2023-06-28','2023-08-07 15:57:43','2023-08-07 15:57:43'),(181,16,'pcs','Baut M16x70x40',100,70000,'2023-06-28','2023-08-07 15:57:43','2023-08-07 15:57:43'),(182,16,'pcs','Baut M16x65x40',100,70000,'2023-06-28','2023-08-07 15:57:43','2023-08-07 15:57:43'),(183,16,'pcs','Baut M16x55 x35',100,70000,'2023-06-28','2023-08-07 15:57:43','2023-08-07 15:57:43'),(184,16,'pcs','Baut m16x30',50,65000,'2023-06-28','2023-08-07 15:57:43','2023-08-07 15:57:43'),(188,26,'pcs','Join flangs reduce exentric 5inc',4,375000,'2023-08-08','2023-08-08 15:04:57','2023-08-08 15:04:57'),(189,26,'pcs','Falngs 1½\" bor lubang ¾inc ss',12,70000,'2023-08-08','2023-08-08 15:04:57','2023-08-08 15:04:57'),(190,26,'pcs','Flangs 2½inc lubang 2inc SW CS',3,70000,'2023-08-08','2023-08-08 15:04:57','2023-08-08 15:04:57'),(191,27,'pcs','Siku 30x19,5',12,200000,'2023-08-22','2023-08-21 22:39:57','2023-08-21 22:39:57'),(192,27,'pcs','Siku 30x30',7,180000,'2023-08-22','2023-08-21 22:39:57','2023-08-21 22:39:57');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `keuangans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keuangans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `amount` int(11) NOT NULL DEFAULT 0,
  `tipe` varchar(255) NOT NULL,
  `balance_after` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `keuangans` WRITE;
/*!40000 ALTER TABLE `keuangans` DISABLE KEYS */;
INSERT INTO `keuangans` VALUES (1,50000,'pemasukan',50000,'testing','2022-10-01 00:32:02','2022-10-01 00:32:02'),(2,20000,'pengeluaran',30000,'pengeluaran cat','2022-10-01 00:33:01','2022-10-01 00:33:01');
/*!40000 ALTER TABLE `keuangans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2022_01_27_050836_create_companies_table',1),(6,'2022_01_27_050914_create_categories_table',1),(7,'2022_01_27_050928_create_products_table',1),(8,'2022_01_27_052044_create_images_products_table',1),(9,'2022_01_27_052820_create_images_sliders_table',1),(10,'2022_07_04_080331_create_invoices_table',1),(11,'2022_07_04_080426_create_items_table',1),(12,'2022_07_04_080456_create_invoice_items_table',1),(13,'2022_07_04_082343_drop_inovice_item_table',1),(14,'2022_08_06_114920_create_deleted_invoices_table',1),(15,'2022_08_06_114933_create_deleted_items_table',1),(16,'2022_08_06_151817_create_penawarans_table',1),(17,'2022_09_22_151552_add_dilihat_to_products_table',2),(18,'2022_09_30_150952_add_tanggal_pengiriman_to_invoice_table',3),(19,'2022_10_01_070515_create_keuangans_table',4),(20,'2022_10_01_072907_add_saldo_to_companies_table',5),(21,'2022_10_01_074407_create_barangs_table',6),(22,'2023_06_02_051137_create_surat_penawarans_table',7),(23,'2023_06_02_051246_create_surat_penawaran_items_table',7);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `penawarans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `penawarans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telp` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `penawarans` WRITE;
/*!40000 ALTER TABLE `penawarans` DISABLE KEYS */;
INSERT INTO `penawarans` VALUES (1,'LinaBet','linaBet@mail.com','+40 2231241065','Ι\'m lооkіng fоr seriоus manǃ..','Нellо аll, guуsǃ Ι knоw, mу meѕsagе mаy bе tоo spесіfic,\r\nВut my ѕiѕtеr found niсе man here аnd they mаrried, sо hоw abоut me?ǃ :)\r\nΙ am 27 уеаrs old, Lіnа, frоm Romanіa, I knоw English and Gеrmаn lаnguаgeѕ аlsо\r\nΑnd... I hаve sрeсіfiс diѕeаѕe, named nymp','2022-11-17 05:14:16','2022-11-17 05:14:16'),(2,'Lucy Williams','lucy@theheritageseo.com','Get higher rankings on Google with SEO at a much lower Cost','Get higher rankings on Google with SEO at a much lower Cost','Hi,\r\n\r\nWe have a team of 55+ highly qualified professionals certified in SEO and ISO standards, providing a wide range of SEO services to generate higher visitor traffic and top-page rankings for your website. Our SEO professionals ensure that your websit','2022-11-28 23:16:26','2022-11-28 23:16:26'),(3,'AlenaOt','alenaOt@crosenoutinabsi.tk','+420 2773100790','Ι am nоt a ϳеalous gіrl. Lookіng for а sеrіouѕ mаn!..','Hеllо!\r\nРеrhaps mу meѕѕage is too ѕpeсifіc.\r\nBut mу older ѕіstеr fоund а wоndеrful man here аnd theу have а grеat relationshіp, but what abоut mе?\r\nΙ am 27 уeаrѕ оld, Alena, frоm thе Сzесh Rерublіс, know Еnglіѕh languagе also\r\nΑnd... bеttеr tо sаy іt imme','2022-12-10 22:50:21','2022-12-10 22:50:21'),(4,'CatherinaOt','catherinaOt@crosenoutinabsi.tk','+420 2727428762','Ι am nоt а jеalous girl. Lоoking for a ѕerіоus mаn!..','Hello!\r\nРеrhapѕ mу mesѕаgе іs toо ѕресіfіc.\r\nBut my oldеr ѕiѕtеr fоund a wоndеrful man hеrе and thеy have а great rеlatiоnship, but what abоut mе?\r\nI am 25 yеars old, Catherіna, frоm the Czech Reрublic, knоw Εnglіѕh lаnguаge аlso\r\nΑnd... bеttеr tо saу іt ','2022-12-29 09:37:52','2022-12-29 09:37:52'),(5,'ChristinaCirm','christinaCirm@denpelatucarenn.tk','+40 2709600946','Girl\'ѕ couple. Ԝе want tо mеet а man!...','Ηellоǃ\r\nI аpоlоgіze for thе overly specіfіc mеѕsagе.\r\nΜy girlfriеnd and I lоve each other. Аnd we аrе аll grеat.\r\nВut... wе nееd a man.\r\nԜе аre 22 уеars оld, from Rоmаniа, wе alsо know englіsh.\r\nԜе nеvеr get boredǃ Αnd not оnly іn tаlk...\r\nΜy name іѕ Сhrі','2023-01-18 19:58:55','2023-01-18 19:58:55'),(6,'Masonpr','masonpr@pmmportfolio.com','84432953989','Do yоu likе thе girl? Do уou wаnt to fuсk hеr?','Сrеate a clone of hеr іn thіs gаme!ǃǃ http://piepocle.gq/prd-55020/\r\nАnd fuсk hеr without limitѕ, аѕ уоu аlways wantеd. She won\'t rеfuѕe уоu!\r\nIf yоu wаnt, fuсk nоt onlу her, but аlso hеr girlfriеnd. Simultanеоuslyǃ\r\n... оr mаybе you wаnt her to fuсk you?','2023-04-06 23:23:19','2023-04-06 23:23:19'),(7,'NataliaTep','nataliaTep@qiamao.com','89279421841','Ι am not а ϳeаlоuѕ gіrl. Lооking fоr a ѕerіоus man!..','Нello!\r\nΡerhaps my mеѕѕаge іѕ tоo sреcifіc.\r\nВut mу oldеr siѕtеr found а wоnderful man herе аnd thеу hаve а grеаt relatіonѕhiр, but whаt аbout mе?\r\nI am 23 yеаrѕ оld, Νаtаlіа, frоm the Czесh Republic, knоw Еnglіѕh languagе also\r\nАnd... bettеr to ѕаy it іm','2023-04-15 12:16:21','2023-04-15 12:16:21'),(8,'Alenawell','alenawell@melodymech.com','88313719178','Саn I fіnd hеrе ѕеrious mаn? :)','Нellо all, guуs! I knоw, mу mesѕаgе mау be too ѕpеcifіc,\r\nΒut my sіstеr found nicе man hеre and thеу mаrrіеd, ѕo hоw аbout me?ǃ :)\r\nI аm 22 yeаrs оld, Αlena, from Romаnia, I knоw Εnglish аnd Gеrman languаges аlso\r\nAnd... Ι have ѕpeсіfiс dіѕease, named nym','2023-06-04 20:40:20','2023-06-04 20:40:20'),(9,'Jason Brookes','jason.brookes@gmail.com','0383-9353440','Dear tunggaljayasurabaya.com Webmaster.','Let me submit your site to 35 classified ad sites for free. Go ahead and claim your free submission here: http://freesubmission.12com.xyz/','2023-06-08 21:07:08','2023-06-08 21:07:08'),(10,'NataliaPl','nataliaPl@noellespodcast.com','89632357639','Ι am an оrdinаrу gіrl. Ι want to mеet аn оrdіnаrу sеrіouѕ mаn.','Ηi!\r\nI\'vе nоtісed thаt mаnу guуs рrefer regular girlѕ.\r\nΙ applaudе thе mеn out thеrе who had thе bаllѕ to еnϳoу the love of manу wоmеn аnd chоoѕе the оnе that hе knew wоuld bе his bеst frіеnd durіng thе bumpу and crаzу thing саllеd lifе.\r\nΙ wanted tо bе t','2023-08-23 23:13:58','2023-08-23 23:13:58'),(11,'JP Corsi','jpcorsi@exitnode.co','+1 954-833-5563','[URGENT] New qualified lead','[URGENT] New qualified lead\r\n\r\nJP Corsi with Exit Node Corp.\r\n\r\nI hope that you are having a good day.\r\n\r\nI am doing a bit of outreach to owner of companies similar to yours as we are seeing increased sales with a number of our clients in the past few mon','2023-09-03 04:10:04','2023-09-03 04:10:04'),(12,'Robertgow','yasen.krasen.13+81957@mail.ru','89238838889','Oiijifekdswdeijfeij jrifwodwodkwifjeikfo jkowkdwkdwfjejfiwkdwdkw jidwoqaskwojefhfisdfjei','Mfhfujfehfueh ifwjifjeighufijsdh uidfsjkdokwefuhgedjij idoweweureiurioweiidkjsdj iwjdsksosjfeihfiwskdoakd ijwdiwdowjfihefiwjdiwhfgue tunggaljayasurabaya.com','2023-09-05 19:59:57','2023-09-05 19:59:57'),(13,'Mariaskig','mariaskig@performancecnc.com','85479164917','Ι аm аn ordіnаrу girl. I want tо meеt аn ordinarу ѕеrious man.','Ηі!\r\nΙ\'ve notiсed that many guуѕ рrefеr rеgular girls.\r\nΙ applаudе the men оut there whо hаd thе bаlls tо enϳoу the lovе of mаny wоmеn and chоose the оnе that he knеw would be hіs beѕt friend durіng the bumpy аnd crazy thіng callеd lіfe.\r\nI wаnted to be t','2023-09-12 02:35:30','2023-09-12 02:35:30');
/*!40000 ALTER TABLE `penawarans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `material` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `rating` varchar(255) NOT NULL,
  `connection` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `dilihat` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,'Gate Valve','gate-valve','Cast Iron,Carbon Steel, Steinless Steel','All size','ANSI 150 / 300 / 600 / 900<br>PN 10 / 16 / 40 / 63<br>JIS 10K / 16K / 20K','flange-end, screw','Kitz, GLT, Toyo dll.','A gate valve, also known as a sluice valve, is a valve that opens by lifting a barrier out of the path of the fluid. Gate valves require very little space along the pipe axis and hardly restrict the flow of fluid when the gate is fully opened. The gate fa','2022-09-21 22:29:45','2023-09-19 07:59:00',106),(2,2,'Globe Valve','globe-valve','Cast Iron,Carbon Steel, Steinless Steel','1/4\" up to 16\"','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Kitz, GLT, Toyo dll.','A globe valve, different from ball valve, is a type of valve used for regulating flow in a pipeline, consisting of a movable plug or disc element and a stationary ring seat in a generally spherical body.','2022-09-21 22:29:45','2023-09-19 07:38:06',119),(3,1,'Ball Valve','ball-valve','Cast Iron,Carbon Steel, Steinless Steel','All size','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Kitz, GLT, Toyo dll.','A ball valve is a flow control device which uses a hollow, perforated and pivoting ball to control liquid flowing through it. It is open when the ball\'s hole is in line with the flow inlet and closed when it is pivoted 90-degrees by the valve handle, bloc','2022-09-21 22:29:45','2023-09-20 11:33:49',115),(4,1,'Swing Check Valve','swing-check-valve','Cast Iron,Carbon Steel, Steinless Steel','All size','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Kitz, GLT, Toyo dll.','The swing check valve is a valve which prevents reverse flow through the pump. Check valves are the variants mainly used for medium-sized to very large nominal diameters. Swing check valves cause low head losses because deflection of the flow is minimal.','2022-09-26 07:03:16','2023-09-19 05:45:11',90),(5,1,'Butterfly Valve','butterfly-valve','Cast Iron,Carbon Steel, Steinless Steel','All size','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Kitz, GLT, Toyo dll.','A butterfly valve is a valve that isolates or regulates the flow of a fluid. The closing mechanism is a disk that rotates','2022-09-26 09:21:21','2023-09-20 18:45:09',94),(6,1,'Plug Valve','plug-valve','Cast Iron,Carbon Steel, Steinless Steel','All size','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Kitz, GLT, Toyo dll.','Plug valves are valves with cylindrical or conically tapered \"plugs\" which can be rotated inside the valve body to control flow through the valve. The plugs in plug valves have one or more hollow passageways going sideways through the plug, so that fluid ','2022-09-26 09:22:33','2023-09-18 20:29:58',82),(7,1,'Safety Valve','safety-valve','Cast Iron,Carbon Steel, Steinless Steel','All size','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Crosby,Spirax sarco, yoshitake, 317 dll','A safety valve is a valve that acts as a fail-safe. An example of safety valve is a pressure relief valve, which automatically releases a substance from a boiler, pressure vessel, or other system, when the pressure or temperature exceeds preset limits.','2022-09-26 09:25:28','2023-09-19 18:12:58',107),(8,1,'Lift Check Valve','lift-check-valve','Cast Iron,Carbon Steel, Steinless Steel','All size','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Kitz, GLT, Toyo dll.','The lift check valve is a valve which prevents the suction line from running empty, e. g. after the pump has been stopped. Priming the pump prior to a re-start is therefore no longer necessary. Spring-loaded lift check valves can be installed in the pipin','2022-09-26 09:26:59','2023-09-11 18:06:43',60),(9,1,'Steam trap','steam-trap','Cast Iron,Carbon Steel, Steinless Steel','All size','jis 10k, jis 20k, jis 30k, ansi 150, ansi 300, ansi 600','flange-end, screw','Gestra, Spirax sarco, Miyawaki','A steam trap is a device used to discharge condensates and non-condensable gases with a negligible consumption or loss of live steam. Steam traps are nothing more than automatic valves. They open, close or modulate automatically','2022-09-26 09:41:56','2023-09-20 22:34:34',109);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `surat_penawaran_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `surat_penawaran_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `suratpenawaran_id` int(11) NOT NULL,
  `item_of` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL,
  `item_price` int(11) NOT NULL,
  `duedate` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=183 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `surat_penawaran_items` WRITE;
/*!40000 ALTER TABLE `surat_penawaran_items` DISABLE KEYS */;
INSERT INTO `surat_penawaran_items` VALUES (1,1,'pcs','Globe valve DN10 PN32mpa',1,3900000,'2023-06-02','2023-06-01 22:21:13','2023-06-01 22:21:13'),(14,2,'pcs','Striner reduce 95x195x200',2,1000000,'2023-06-05','2023-06-05 21:17:22','2023-06-05 21:17:22'),(15,2,'pcs','Strainer reduce 120x295x405',2,1500000,'2023-06-05','2023-06-05 21:17:22','2023-06-05 21:17:22'),(16,2,'pcs','Strainer reduce 100x580x240',1,1300000,'2023-06-05','2023-06-05 21:17:22','2023-06-05 21:17:22'),(17,3,'pcs','L m12 x 30',40,50000,'2023-06-13','2023-06-13 04:39:03','2023-06-13 04:39:03'),(18,3,'pcs','L m16 x 30',20,65000,'2023-06-13','2023-06-13 04:39:03','2023-06-13 04:39:03'),(19,3,'pcs','L m16 x 55',20,65000,'2023-06-13','2023-06-13 04:39:03','2023-06-13 04:39:03'),(20,3,'pcs','L m16 x 110',5,90000,'2023-06-13','2023-06-13 04:39:03','2023-06-13 04:39:03'),(22,5,'pcs','Safety valve 1inc x 1½inc ss304 pressure 16,4bar connection flangs pn40',1,8250000,'2023-06-26','2023-06-26 16:29:06','2023-06-26 16:29:06'),(23,5,'pcs','Ball valve sus 304 kitz ½inc jis 10k rf connection flangs',1,1350000,'2023-06-26','2023-06-26 16:29:06','2023-06-26 16:29:06'),(24,6,'pcs','Gate valve 8\" ss 304',3,31000000,'2023-07-03','2023-07-02 21:11:16','2023-07-02 21:11:16'),(25,6,'pcs','Globe valve 4\" ss304',1,22500000,'2023-07-03','2023-07-02 21:11:16','2023-07-02 21:11:16'),(26,6,'pcs','Gate valve 6\" ss304',2,27500000,'2023-07-03','2023-07-02 21:11:16','2023-07-02 21:11:16'),(29,9,'pcs','Waterfly valve aqtuator',3,1250000,'2023-07-13','2023-07-12 23:32:55','2023-07-12 23:32:55'),(159,10,'pcs','PIPING HEADER DARI DELUGE',1,13130000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(160,10,'pcs','PIPE LINE 4\"',1,27585000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(161,10,'pcs','PENCABANGAN SPRAYER',1,60599500,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(162,10,'pcs','HIDRANT',1,13360000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(163,10,'pcs','ELECTRIK\r\n- PENGGANTIAN KABEL TRAY KE JBFS',1,3250000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(164,10,'pcs','KABEL TRAY DARI PANEL FA KE JBFS',1,6629900,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(165,10,'pcs','KABEL DARI FA KE DELUGE HEADER',1,4298000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(166,10,'pcs','KABEL DARI FA KE JBFA',1,4845000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(167,10,'pcs','PENARIKAN KABEL JBFA-CONVEYOR\r\nBC-01A/B',1,8059350,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(168,10,'pcs','PENARIKAN KABEL JBFA-CONVEYOR\r\nBC-02B',1,13784700,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(169,10,'pcs','PENARIKAN KABEL JBFA-CONVEYOR\r\nBC-03A/B',1,17480400,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(170,10,'pcs','PENARIKAN KABEL JBFA-CONVEYOR\r\nBC-04A/B',1,4235200,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(171,10,'pcs','PENARIKAN KABEL JBFA-BUCKET\r\nELEVATOR BE-01A/B',1,5154000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(172,10,'pcs','PENARIKAN KABEL JBFA-HEAT\r\nDETECTOR SILO',1,10590000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(173,10,'pcs','Kabel JBFA-HORN STROBE\r\nDI HIDRANT B',1,7537000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(174,10,'pcs','KABEL JBFA-BREAK GLASS\r\nDI HIDRANT B',1,8362500,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(175,10,'pcs','KABEL TRAY DARI PANEL KE SILO',1,20675000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(176,10,'pcs','SCADA TEMPERATURE',1,7500000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(177,10,'pcs','DIREKSI KIT/SHELTER',1,8000000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(178,10,'pcs','PENGECATAN',1,23110000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(179,10,'pcs','PENGUJIAN PEKERJAAN PIPA',1,6728000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(180,10,'pcs','MOBILISASI DAN DEMOB MANPOWER',1,16500000,'2023-07-26','2023-07-26 18:05:24','2023-07-26 18:05:24'),(181,11,'pcs','Ball valve bras scruw 1inc  kitz',5,308400,'2023-08-09','2023-08-09 06:15:44','2023-08-09 06:15:44'),(182,11,'pcs','Ball valve bronze 4inc scruw kitz',1,6041600,'2023-08-09','2023-08-09 06:15:44','2023-08-09 06:15:44');
/*!40000 ALTER TABLE `surat_penawaran_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `surat_penawarans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `surat_penawarans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_pnw` int(11) DEFAULT NULL,
  `no_surat` varchar(255) NOT NULL,
  `duedate` date DEFAULT NULL,
  `name_customer` varchar(255) DEFAULT NULL,
  `address_customer` varchar(255) DEFAULT NULL,
  `phone_customer` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `surat_penawarans` WRITE;
/*!40000 ALTER TABLE `surat_penawarans` DISABLE KEYS */;
INSERT INTO `surat_penawarans` VALUES (1,1,'2023/PNW/06/0001','2023-06-02','PT SMSE','Kupang','+62 857-2964-6447','Garansi 6 bulan setelah barang diterima ( garansi berupa sarvice di workshop kami)','2023-06-01 22:21:12','2023-06-01 22:21:12'),(2,1,'2023/PNW/06/0001','2023-06-05','Bpk amir','Sidoarjo / tuban','+62 813-5784-0907','Tukar tambah strainer KRI','2023-06-05 05:21:12','2023-06-05 05:34:58'),(3,1,'2023/PNW/06/0001','2023-06-13','Bpk samsul','Gersik','+62 812-3555-9990','Jasa pembuatan baut L  non mur bahan besi SCM','2023-06-13 04:39:03','2023-06-13 04:39:03'),(5,1,'2023/PNW/06/0001','2023-06-26','Pt leewon','Gersik','+62 881-9835-572',NULL,'2023-06-26 16:29:06','2023-06-26 16:29:06'),(6,1,'2023/PNW/07/0001','2023-07-03','Bpk budi','Perak surabaya','+62 812-3074-4019','Unit fabrikasi flangs  dengan tempo pekerjaan max 30hr kerja beserta hidrotes .\r\nMasa garansi selama 3bln','2023-07-02 21:11:16','2023-07-02 21:11:16'),(9,1,'2023/PNW/07/0001','2023-07-13','PT KITA HOKKI','Surabaya','+62 812-3941-9955','Jasa pekerjaan  bonkar dan  setting aqtuator watterfly valve CI dengan penawaran diatas .\r\nSebagai mana pekerjaan yg kami lakukan ada pembokaran tutup piston untuk menabahkan gemukdan pergantian oring .\r\nDan pekerjaan dilakukan di workshop kami .','2023-07-12 23:05:04','2023-07-12 23:32:27'),(10,1,'2023/PNW/07/0001','2023-07-26','PT Surya Sumber Sejahtera','Jl. Darmo Harapan Utara I Blok EM/11 ,Surabaya','0317381818','PERIHAL PERINCIAN PEKERJAAN DI AJINOMOTO MOJOKERTO','2023-07-26 17:03:40','2023-07-26 18:05:24'),(11,1,'2023/PNW/08/0001','2023-08-09','Bpk luqman','Wringin anom km33 gersik','085730304422','Kami menawarkan ball valve kuningan  dengan spesifikasi berikut .\r\n0embayaran bisamelalui tranfer bank \r\nCHUSNUL IMRON\r\nBank Mandiri\r\n1410018628487\r\nBca 6710085453','2023-08-09 06:15:44','2023-08-09 06:15:44');
/*!40000 ALTER TABLE `surat_penawarans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin@gmail.com',NULL,'$2y$10$ZjqG4OWvCDLwzXVy1GfIUeWZbCZf6yJbf875iGJGS//sFcjUnqj5i',NULL,'2022-09-21 22:29:45','2022-09-21 22:29:45');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

