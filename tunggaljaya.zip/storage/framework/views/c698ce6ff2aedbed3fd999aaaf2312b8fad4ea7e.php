<head>
  <style>
    .logo {
      width: 2.5cm;
    }
  </style>
</head>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class="row">
        <div class="col-xs-12">
    		<div class="invoice-title">
    			<h2>Invoice</h2><h3 class="pull-right">Order #<?php echo e($invoice->no_invoice); ?></h3>
    		</div>
    		<hr>
    		<div class="row">
    			<div class="col-xs-6">
    				<address>
              <div>
                <img src="<?php echo e(asset($company->image_company)); ?>" class="logo">
              </div>
    				<strong><?php echo e($company->name); ?></strong><br>
            <?php echo e($company->address); ?><br>
            Email : <?php echo e($company->email); ?>

    				</address>
    			</div>
    			<div class="col-xs-6 text-right">
    				<address>
        			<strong>Kepada:</strong><br>
    					<?php echo e($invoice->name_customer); ?><br>
              <?php echo e($invoice->address_customer); ?><br>
              <?php echo e($invoice->phone_customer); ?>

    				</address>
    			</div>
    		</div>
    		<div class="row">
    			
    			<div class="col-xs-6">
    				<address>
    					<strong>Order Date:</strong><br>
    					<?php echo e($date_inv); ?><br><br>
    				</address>
    			</div>
    		</div>
    	</div>
    </div>
    
    <div class="row">
    	<div class="col-md-12">
    		<div class="panel panel-default">
    			<div class="panel-heading">
    				<h3 class="panel-title"><strong>Order</strong></h3>
    			</div>
    			<div class="panel-body">
    				<div class="table-responsive">
    					<table class="table table-condensed">
    						<thead>
                                <tr>
        							<td><strong>Nama barang</strong></td>
        							<td class="text-center"><strong>Harga</strong></td>
        							<td class="text-center"><strong>Jumlah</strong></td>
        							<td class="text-right"><strong>Total</strong></td>
                                </tr>
    						</thead>
    						<tbody>
    							<!-- foreach ($order->lineItems as $line) or some such thing here -->
    							<?php $subtotal = 0; ?>
                  <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->description); ?></td>
                        <td class="text-center">Rp. <?php echo number_format($item->item_price,0,',','.'); ?></td>
                        <td class="text-center"><?php echo e($item->qty); ?></td>
                        <td class="text-right">Rp. <?php echo number_format($item->item_price * $item->qty,0,',','.'); ?></td>
                    </tr>
                    <?php $subtotal += $item->item_price * $item->qty; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    							<tr>
    								<td class="thick-line"></td>
    								<td class="thick-line"></td>
    								<td class="thick-line text-center"><strong>Subtotal</strong></td>
    								<td class="thick-line text-right">Rp. <?php echo number_format($subtotal,0,',','.'); ?></td>
    							</tr>
    							<tr>
    								<td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line text-center"><strong>Diskon</strong></td>
    								<td class="no-line text-right">Rp. <?php echo number_format($subtotal*$invoice->diskon_rate,0,',','.'); ?> (<?php echo e($invoice->diskon_rate); ?>%)</td>
    							</tr>
    							<tr>
    								<td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line text-center"><strong>Total</strong></td>
    								<td class="no-line text-right">Rp. <?php echo number_format($subtotal-($subtotal*$invoice->diskon_rate),0,',','.'); ?></td>
    							</tr>
    						</tbody>
    					</table>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
</div><?php /**PATH D:\proyek\tunggaljaya\resources\views/admin/invoice-show-new.blade.php ENDPATH**/ ?>