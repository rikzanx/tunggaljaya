<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <style>
        body {
      background: #ccc;
      padding: 30px;
    }
    
    .container {
      width: 21cm;
      min-height: 29.7cm;
    }
    
    .invoice {
      background: #fff;
      width: 100%;
      padding: 50px;
    }
    
    .logo {
      width: 2.5cm;
    }
    
    .document-type {
      text-align: right;
      color: #444;
    }
    
    .conditions {
      font-size: 0.7em;
      color: #666;
    }
    
    .bottom-page {
      font-size: 0.7em;
    }
    </style>
</head>
<div class="container">
    <div class="invoice">
      <div class="row">
        <div class="col-7">
          <img src="<?php echo e(asset($company->image_company)); ?>" class="logo">
          <p>
            <strong><?php echo e($company->name); ?></strong><br>
            <?php echo e($company->address); ?><br>
            Phone : <?php echo e($company->telp); ?>

          </p>
        </div>
        <div class="col-5">
          <h1 class="document-type display-4">INVOICE</h1>
          <p class="text-end">
            <strong>No: <?php echo e($invoice->no_invoice); ?></strong>
            <br>
            <strong>Date: <?php echo e($date_inv); ?></strong>
          </p>
        </div>
      </div>
      <div class="row">
        <div class="col-7">
          <p>
            <strong>Bill to</strong><br>
            <?php echo e($invoice->name_customer); ?><br>
            <?php echo e($invoice->address_customer); ?><br>
            <?php echo e($invoice->phone_customer); ?>

          </p>
        </div>
        
      </div>
      <br>
      
      <br>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>No</th>
            <th>Description</th>
            <th>Qty</th>
            <th>Item Price</th>
            <th>Total amount</th>
          </tr>
        </thead>
        <tbody>
          <?php $subtotal = 0; ?>
          <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->index+1); ?></td>
                <td><?php echo e($item->description); ?></td>
                <td><?php echo e($item->qty); ?></td>
                <td class="text-right">Rp. <?php echo number_format($item->item_price,0,',','.'); ?></td>
                <td class="text-right">Rp. <?php echo number_format($item->item_price * $item->qty,0,',','.'); ?></td>
            </tr>
            <?php $subtotal += $item->item_price * $item->qty; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div class="row">
        <div class="col-8">
        </div>
        <div class="col-4">
          <table class="table table-sm text-right">
            <tr>
              <td><strong>Subtotal</strong></td>
              <td class="text-right">Rp. <?php echo number_format($subtotal,0,',','.'); ?></td>
            </tr>
            <tr>
              <td>Diskon</td>
              <td class="text-right">Rp. <?php echo number_format($subtotal*$invoice->diskon_rate,0,',','.'); ?> (<?php echo e($invoice->diskon_rate); ?>%)</td>
            </tr>
            <tr>
              <td><strong>Total</strong></td>
              <td class="text-right">Rp. <?php echo number_format($subtotal-($subtotal*$invoice->diskon_rate),0,',','.'); ?></td>
            </tr>
          </table>
        </div>
      </div>
      
      <p class="conditions">
        <strong>Catatan Tambahan :</strong><br>
        <?php echo e($invoice->comment); ?>

      </p>
      
      <br>
      <br>
      <br>
      <br>
      
      
    </div>
  </div><?php /**PATH D:\proyek\harapanbaru\resources\views/admin/invoice-show.blade.php ENDPATH**/ ?>